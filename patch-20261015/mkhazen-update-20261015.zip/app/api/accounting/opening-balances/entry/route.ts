/**
 * POST /api/accounting/opening-balances/entry — إدخال رصيد افتتاحي (متكرر)
 *   { kind: "CASH", account, currency, amount, notes }       → record_opening_cash
 *   { kind: "INVENTORY", variantId, quantity, unitCost, notes } → record_opening_inventory
 * للمالك والمدير. ذرّي + منع التكرار بـ Idempotency-Key.
 */

import { revalidatePath } from "next/cache";
import { z } from "zod";

import { MAIN_BRANCH_ID } from "@/lib/constants";
import { requirePermission } from "@/lib/permissions-server";
import { supabaseAdmin } from "@/lib/supabase";
import { runIdempotentRpc } from "@/lib/idempotency";
import { apiError, invalidJsonResponse, readJson } from "@/lib/api-response";

const twoDecimals = (value: number) => Number(value.toFixed(2)) === value;

const entrySchema = z.discriminatedUnion("kind", [
  z.object({
    kind: z.literal("CASH"),
    account: z.enum(["CASH", "BANK"], { message: "الحساب غير صالح" }),
    currency: z.enum(["SDG", "USD"], { message: "العملة غير صالحة" }),
    amount: z.number().positive("المبلغ يجب أن يكون أكبر من صفر").refine(twoDecimals, "منزلتين عشريتين كحد أقصى"),
    notes: z.string().trim().max(300).nullable().optional(),
  }),
  z.object({
    kind: z.literal("INVENTORY"),
    variantId: z.string().uuid("اختر المنتج والمتغير"),
    quantity: z.number().positive("الكمية يجب أن تكون أكبر من صفر").refine(twoDecimals, "منزلتين عشريتين كحد أقصى"),
    unitCost: z.number().positive("تكلفة الوحدة يجب أن تكون أكبر من صفر").refine(twoDecimals, "منزلتين عشريتين كحد أقصى"),
    notes: z.string().trim().max(300).nullable().optional(),
  }),
]);

export async function POST(request: Request) {
  const guard = await requirePermission("accounting.openingBalances", "الأرصدة الافتتاحية متاحة للمالك أو المدير فقط.");
  if (!guard.ok) return guard.response;
  const user = guard.session;

  const body = await readJson(request);
  if (body === null) return invalidJsonResponse();

  const validation = entrySchema.safeParse(body);
  if (!validation.success) {
    return apiError(422, "VALIDATION_ERROR", "بيانات الرصيد الافتتاحي غير صالحة.", {
      errors: validation.error.flatten().fieldErrors,
    });
  }
  const value = validation.data;

  return runIdempotentRpc<Record<string, unknown>>({
    request,
    scope: "accounting.opening-entry",
    userId: user.userId,
    payload: value,
    context: value.kind === "CASH" ? "record_opening_cash" : "record_opening_inventory",
    fallbackMessage: "تعذر تسجيل الرصيد الافتتاحي.",
    rpc: () =>
      value.kind === "CASH"
        ? supabaseAdmin.rpc("record_opening_cash", {
            p_branch_id: MAIN_BRANCH_ID,
            p_user_id: user.userId,
            p_account: value.account,
            p_currency: value.currency,
            p_amount: value.amount,
            p_notes: value.notes ?? null,
          })
        : supabaseAdmin.rpc("record_opening_inventory", {
            p_branch_id: MAIN_BRANCH_ID,
            p_user_id: user.userId,
            p_variant_id: value.variantId,
            p_quantity: value.quantity,
            p_unit_cost: value.unitCost,
            p_notes: value.notes ?? null,
          }),
    onSuccess: (data) => {
      revalidatePath("/dashboard/accounting/opening-balances");
      return {
        status: 201,
        body: {
          message: value.kind === "CASH" ? "تم تسجيل الرصيد الافتتاحي للأموال." : "تم تسجيل المخزون الافتتاحي.",
          data,
        },
      };
    },
  });
}
