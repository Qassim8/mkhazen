// src/app/dashboard/employees/services/employees.services.ts
import { serverFetch } from "@/lib/api-client";
import { AdminResetPasswordInput } from "@/lib/validations/auth.schemas";
import {
  CreateEmployeeInput,
  Employee,
  EmployeeQueryParams,
  UpdateEmployeeInput,
} from "@/app/dashboard/employees/schemas/employee.schemas";

export interface EmployeesResponse {
  data: Employee[];
  meta: {
    totalCount: number;
    totalPages: number;
    currentPage: number;
    limit: number;
  };
}

export const getEmployees = async (params: EmployeeQueryParams) => {
  return serverFetch<EmployeesResponse>("/api/users", {
    method: "GET",
    params,
    next: { tags: ["employees-list"] },
  });
};

export const creatEmployee = async (data: CreateEmployeeInput) => {
  return serverFetch<{ message: string; data: Employee; temporaryPassword?: string }>("/api/users", {
    method: "POST",
    body: JSON.stringify(data),
  });
};

export const updateEmployee = async (id: string, data: UpdateEmployeeInput) => {
  const isTailor = data.position === "tailor";

  // نسبة العمولة لم تعد تُستخدم (أجرة الخياط تُحدد في كل طلب): لا تُرسل ولا تتغير في القاعدة
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { commissionRate: _commissionRate, ...rest } = data;
  const payload = {
    ...rest,
    isActive: Boolean(data.isActive),
    salary: !isTailor ? Number(data.salary ?? 0) : 0,
  };

  return serverFetch<{ message: string; data: Employee }>(`/api/users/${id}`, {
    method: "PUT",
    body: JSON.stringify(payload),
  });
};

export const deleteEmployee = async (rowId: string | number) => {
  return serverFetch<{ message: string; data: Employee }>(`/api/users/${rowId}`, {
    method: "DELETE",
  });
};

export const resetEmployeePassword = async (
  id: string,
  data: AdminResetPasswordInput,
) => {
  // استدعاء نقطة النهاية المجهزة مسبقاً للتحديث
  return serverFetch<{ message: string }>(`/api/users/${id}`, {
    method: "PUT", // أو PUT حسب المتبع لديك في API التحديث
    body: JSON.stringify({
      password: data.password,
      resetRequested: false,
    }),
  });
};
