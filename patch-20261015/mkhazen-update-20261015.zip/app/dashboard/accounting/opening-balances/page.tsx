import { redirect } from "next/navigation";

import { getSession } from "@/lib/auth";
import { can } from "@/lib/permissions";
import BackLink from "@/components/shared/BackLink";
import { getSupplierOptions } from "@/app/dashboard/suppliers/services/supplier.services";

import { MAIN_BRANCH_ID } from "@/lib/constants";
import { supabaseAdmin } from "@/lib/supabase";
import { fetchAll } from "@/lib/supabase-fetch-all";

import OpeningBalancesClient from "../_components/OpeningBalancesClient";
import type { OpeningVariantOption } from "../_components/OpeningInventorySection";
import { getOpeningBalancesStatus } from "../services/opening-balances.services";
import type { OpeningBalancesStatus } from "../schemas/opening-balances.schema";

export const dynamic = "force-dynamic";

function variantLabel(variant: Record<string, unknown>) {
  return [
    variant.colorName ? String(variant.colorName) : null,
    variant.size ? `مقاس ${variant.size}` : null,
  ]
    .filter(Boolean)
    .join(" • ");
}

export default async function OpeningBalancesPage() {
  const user = await getSession();

  if (!user || !can(user.role, "accounting.openingBalances")) {
    redirect("/dashboard/accounting");
  }

  let status: OpeningBalancesStatus | null = null;
  let loadError: string | null = null;

  try {
    status = await getOpeningBalancesStatus();
  } catch (error) {
    // أشهر سبب: ملف 20261010_05_opening_balances.sql لم يُطبَّق بعد على قاعدة البيانات
    loadError = error instanceof Error ? error.message : "تعذر جلب الأرصدة الافتتاحية.";
  }

  if (!status) {
    return (
      <main dir="rtl" className="space-y-5">
        <div className="mb-3">
          <BackLink href="/dashboard/accounting" label="العودة إلى المحاسبة" />
        </div>
        <div className="rounded-2xl border border-amber-200 bg-amber-50 p-6">
          <h1 className="text-lg font-black text-amber-900">الأرصدة الافتتاحية غير مفعّلة بعد</h1>
          <p className="mt-2 text-sm text-amber-900">
            شغّل ملف{" "}
            <code className="rounded bg-amber-100 px-1.5 py-0.5 font-mono text-xs">
              database/migrations/20261010_05_opening_balances.sql
            </code>{" "}
            على قاعدة البيانات في Supabase، ثم حدّث الصفحة.
          </p>
          <p className="mt-3 font-mono text-xs break-all text-amber-700">{loadError}</p>
        </div>
      </main>
    );
  }

  const suppliers = await getSupplierOptions()
    .then((response) => response.data.map((supplier) => ({ id: supplier.id, name: supplier.name, isActive: supplier.isActive })))
    .catch(() => []);

  // المخزون الافتتاحي: الأصناف النشطة + ما سُجّل بقيود JE-OPENINV
  const [variants, inventoryResult] = await Promise.all([
    fetchAll<Record<string, unknown>>((from, to) =>
      supabaseAdmin
        .from("product_variants")
        .select('id, sku, "colorName", size, "stockQuantity", "averageCost", product_templates!inner(name, "sellingUnit", "isActive")')
        .eq("isActive", true)
        .order("id")
        .range(from, to),
    ).catch(() => [] as Record<string, unknown>[]),
    supabaseAdmin
      .from("journal_entries")
      .select("id, description, amount_usd, created_at")
      .eq("branch_id", MAIN_BRANCH_ID)
      .like("entry_number", "JE-OPENINV-%")
      .order("created_at", { ascending: false })
      .limit(100),
  ]);

  const variantOptions: OpeningVariantOption[] = variants
    .filter((variant) => ((variant.product_templates ?? {}) as Record<string, unknown>).isActive !== false)
    .map((variant) => {
      const template = (variant.product_templates ?? {}) as Record<string, unknown>;
      return {
        id: String(variant.id),
        productName: String(template.name ?? "منتج"),
        variantLabel: variantLabel(variant),
        sku: variant.sku ? String(variant.sku) : null,
        unit: template.sellingUnit ? String(template.sellingUnit) : "",
        stock: Number(variant.stockQuantity ?? 0),
        averageCost: Number(variant.averageCost ?? 0),
      };
    })
    .sort((a, b) => a.productName.localeCompare(b.productName, "ar"));

  const inventoryEntries = (inventoryResult.data ?? []).map((row) => ({
    id: String(row.id),
    description: row.description ? String(row.description) : "",
    amountUsd: Number(row.amount_usd ?? 0),
    createdAt: String(row.created_at),
  }));

  return (
    <OpeningBalancesClient
      status={status}
      suppliers={suppliers}
      variants={variantOptions}
      inventoryEntries={inventoryEntries}
    />
  );
}
