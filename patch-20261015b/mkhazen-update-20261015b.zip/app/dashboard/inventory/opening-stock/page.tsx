import { redirect } from "next/navigation";

import { getSession } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { MAIN_BRANCH_ID } from "@/lib/constants";
import { supabaseAdmin } from "@/lib/supabase";
import { fetchAll } from "@/lib/supabase-fetch-all";
import BackLink from "@/components/shared/BackLink";

import OpeningInventorySection, {
  type OpeningVariantOption,
} from "../_components/OpeningInventorySection";

export const dynamic = "force-dynamic";

function variantLabel(variant: Record<string, unknown>) {
  return [
    variant.colorName ? String(variant.colorName) : null,
    variant.size ? `مقاس ${variant.size}` : null,
  ]
    .filter(Boolean)
    .join(" • ");
}

/**
 * المخزون الافتتاحي (منفصل عن الأرصدة المالية الافتتاحية):
 * يزيد الرصيد، متوسط مرجح للتكلفة، حركة OPENING، وقيد مدين المخزون / دائن رأس المال.
 */
export default async function OpeningStockPage() {
  const user = await getSession();
  if (!user || !can(user.role, "inventory.openingStock")) redirect("/dashboard/inventory");

  const [variants, entriesResult] = await Promise.all([
    fetchAll<Record<string, unknown>>((from, to) =>
      supabaseAdmin
        .from("product_variants")
        .select('id, sku, "colorName", size, "stockQuantity", "averageCost", product_templates!inner(name, "sellingUnit", "isActive")')
        .eq("isActive", true)
        .order("id")
        .range(from, to),
    ),
    supabaseAdmin
      .from("journal_entries")
      .select("id, description, amount_usd, created_at")
      .eq("branch_id", MAIN_BRANCH_ID)
      .like("entry_number", "JE-OPENINV-%")
      .order("created_at", { ascending: false })
      .limit(100),
  ]);

  if (entriesResult.error) {
    throw new Error(`تعذر جلب المخزون الافتتاحي: ${entriesResult.error.message}`);
  }

  const variantOptions: OpeningVariantOption[] = variants
    .filter((variant) => ((variant.product_templates ?? {}) as Record<string, unknown>).isActive !== false)
    .map((variant) => {
      const template = (variant.product_templates ?? {}) as Record<string, unknown>;
      return {
        id: String(variant.id),
        productName: String(template.name ?? "منتج"),
        variantLabel: variantLabel(variant),
        sku: variant.sku ? String(variant.sku) : null,
        unit: template.sellingUnit ? String(template.sellingUnit) : "",
        stock: Number(variant.stockQuantity ?? 0),
        averageCost: Number(variant.averageCost ?? 0),
      };
    })
    .sort((a, b) => a.productName.localeCompare(b.productName, "ar"));

  const entries = (entriesResult.data ?? []).map((row) => ({
    id: String(row.id),
    description: row.description ? String(row.description) : "",
    amountUsd: Number(row.amount_usd ?? 0),
    createdAt: String(row.created_at),
  }));

  return (
    <main dir="rtl" className="space-y-6 p-4 pb-12">
      <div className="border-b border-gray-100 pb-4">
        <div className="mb-3">
          <BackLink href="/dashboard/inventory" label="العودة إلى المخزون" />
        </div>
        <h1 className="text-2xl font-black text-gray-950">المخزون الافتتاحي</h1>
        <p className="mt-1 text-sm text-gray-500">
          البضاعة الموجودة قبل بدء استخدام النظام. يقبل الإدخال أكثر من مرة لاستكمال ما نُسي:
          يزيد الرصيد ويحدّث متوسط التكلفة بالمتوسط المرجح، ويُنشئ قيد مدين المخزون / دائن رأس المال.
        </p>
      </div>

      <section className="rounded-2xl border border-gray-200 bg-white p-5">
        <OpeningInventorySection variants={variantOptions} entries={entries} />
      </section>
    </main>
  );
}
