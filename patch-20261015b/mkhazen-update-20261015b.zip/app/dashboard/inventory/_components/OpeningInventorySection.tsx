"use client";

/**
 * المخزون الافتتاحي (يقبل الإدخال أكثر من مرة):
 * منتج ومتغير + كمية + تكلفة الوحدة بالدولار ← يزيد الرصيد، متوسط مرجح للتكلفة،
 * حركة مخزون OPENING، وقيد مدين المخزون / دائن رأس المال.
 */

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";

import { serverFetch } from "@/lib/api-client";
import { formatQuantity, formatUSD } from "@/lib/currency";
import { useIdempotencyKey } from "@/lib/use-idempotency-key";

export interface OpeningVariantOption {
  id: string;
  productName: string;
  variantLabel: string;
  sku: string | null;
  unit: string;
  stock: number;
  averageCost: number;
}

export interface OpeningInventoryEntry {
  id: string;
  description: string;
  amountUsd: number;
  createdAt: string;
}

const inputClass =
  "w-full rounded-xl border border-gray-200 bg-white px-3 py-2.5 text-sm outline-none focus:border-(--primary-red)";

function dateTimeLabel(value: string) {
  return new Intl.DateTimeFormat("ar-SA-u-nu-latn", {
    dateStyle: "medium",
    timeStyle: "short",
    timeZone: "Africa/Khartoum",
  }).format(new Date(value));
}

export default function OpeningInventorySection({
  variants,
  entries,
}: {
  variants: OpeningVariantOption[];
  entries: OpeningInventoryEntry[];
}) {
  const router = useRouter();
  const idempotency = useIdempotencyKey();
  const [search, setSearch] = useState("");
  const [variantId, setVariantId] = useState("");
  const [quantity, setQuantity] = useState("");
  const [unitCost, setUnitCost] = useState("");
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    const list = term
      ? variants.filter((variant) =>
          [variant.productName, variant.variantLabel, variant.sku ?? ""].some((text) =>
            text.toLowerCase().includes(term),
          ),
        )
      : variants;
    return list.slice(0, 200);
  }, [search, variants]);

  const selected = variants.find((variant) => variant.id === variantId) ?? null;
  const qty = Number(quantity);
  const cost = Number(unitCost);

  async function submit() {
    if (!variantId) {
      toast.error("اختر المنتج والمتغير.");
      return;
    }
    if (!Number.isFinite(qty) || qty <= 0 || !Number.isFinite(cost) || cost <= 0) {
      toast.error("أدخل كمية وتكلفة وحدة أكبر من صفر.");
      return;
    }

    const payload = { kind: "INVENTORY", variantId, quantity: qty, unitCost: cost, notes: notes.trim() || null };
    setSaving(true);
    try {
      const response = await serverFetch<{ message?: string }>("/api/accounting/opening-balances/entry", {
        method: "POST",
        body: JSON.stringify(payload),
        headers: { "Idempotency-Key": idempotency.keyFor(payload) },
      });
      idempotency.reset();
      toast.success(response.message ?? "تم تسجيل المخزون الافتتاحي.");
      setQuantity("");
      setUnitCost("");
      setNotes("");
      router.refresh();
    } catch (error: unknown) {
      toast.error(error instanceof Error ? error.message : "تعذر تسجيل المخزون الافتتاحي.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-4">
      <div className="grid gap-3 lg:grid-cols-2">
        <div className="space-y-2 lg:col-span-2">
          <input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="ابحث باسم المنتج أو SKU..."
            className={inputClass}
            disabled={saving}
          />
          <select
            value={variantId}
            onChange={(event) => setVariantId(event.target.value)}
            className={inputClass}
            size={6}
            disabled={saving}
          >
            {filtered.map((variant) => (
              <option key={variant.id} value={variant.id}>
                {variant.productName}
                {variant.variantLabel ? ` — ${variant.variantLabel}` : ""}
                {variant.sku ? ` (${variant.sku})` : ""} — الرصيد {formatQuantity(variant.stock)} {variant.unit}
              </option>
            ))}
          </select>
          {selected && (
            <p className="text-xs text-gray-500">
              الرصيد الحالي: {formatQuantity(selected.stock)} {selected.unit} — متوسط التكلفة:{" "}
              {formatUSD(selected.averageCost)}
            </p>
          )}
        </div>
        <label className="block">
          <span className="text-xs font-bold text-gray-600">الكمية</span>
          <input type="number" min="0.01" step="0.01" inputMode="decimal" value={quantity} onChange={(event) => setQuantity(event.target.value)} className={inputClass} disabled={saving} />
        </label>
        <label className="block">
          <span className="text-xs font-bold text-gray-600">تكلفة الوحدة ($)</span>
          <input type="number" min="0.01" step="0.01" inputMode="decimal" value={unitCost} onChange={(event) => setUnitCost(event.target.value)} className={inputClass} disabled={saving} />
        </label>
        <label className="block lg:col-span-2">
          <span className="text-xs font-bold text-gray-600">ملاحظات</span>
          <input value={notes} onChange={(event) => setNotes(event.target.value)} maxLength={300} className={inputClass} disabled={saving} />
        </label>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <button
          type="button"
          onClick={submit}
          disabled={saving}
          className="rounded-xl bg-gray-900 px-6 py-2.5 text-xs font-bold text-white disabled:opacity-50"
        >
          {saving ? "جارٍ الحفظ..." : "تسجيل المخزون الافتتاحي"}
        </button>
        {qty > 0 && cost > 0 && (
          <span className="text-xs font-semibold text-emerald-700">
            القيمة: {formatUSD(qty * cost)} (مدين المخزون / دائن رأس المال)
          </span>
        )}
      </div>

      {entries.length > 0 && (
        <ul className="divide-y divide-gray-100 rounded-xl border border-gray-100 text-sm">
          {entries.map((entry) => (
            <li key={entry.id} className="flex flex-wrap items-center justify-between gap-2 px-3 py-2">
              <span>{entry.description}</span>
              <span className="text-xs text-gray-500">
                {formatUSD(entry.amountUsd)} — {dateTimeLabel(entry.createdAt)}
              </span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
