import { redirect } from "next/navigation";

import { getSession } from "@/lib/auth";
import { can } from "@/lib/permissions";

import TailorDuesClient from "../_components/TailorDuesClient";
import { getTailorDues } from "../services/accounting.services";

const TailorDuesPage = async () => {
  const user = await getSession();
  if (!user) redirect("/login");

  const { data, totals } = await getTailorDues();

  return (
    <TailorDuesClient
      initialData={data}
      totals={totals}
      canPay={can(user.role, "accounting.manage")}
    />
  );
};

export default TailorDuesPage;
