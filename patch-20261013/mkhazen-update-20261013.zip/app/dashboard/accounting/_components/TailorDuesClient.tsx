"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";
import { LuFileText, LuHandCoins, LuWalletCards, LuX } from "react-icons/lu";

import { formatSDG, formatUSD } from "@/lib/currency";
import { useIdempotencyKey } from "@/lib/use-idempotency-key";

import type {
  TailorDuesRow,
  TailorStatement,
} from "../schemas/accounting.schema";
import { getTailorStatement, payTailorDues } from "../services/accounting.services";

interface Props {
  initialData: TailorDuesRow[];
  totals: { remainingSdg: number; advancesSdg: number };
  canPay: boolean;
}

type PayKind = "SETTLEMENT" | "ADVANCE";

const PAYMENT_TYPE_LABELS: Record<string, string> = {
  SETTLEMENT: "سداد مستحقات",
  DUES_ADVANCE: "سلفة",
  ADVANCE: "دفعة مقدمة (قبل التثبيت)",
};

function dateTimeLabel(value: string) {
  if (!value) return "-";
  return new Intl.DateTimeFormat("ar-SA-u-nu-latn", {
    dateStyle: "medium",
    timeStyle: "short",
    timeZone: "Africa/Khartoum",
  }).format(new Date(value));
}

function ModalShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      {children}
    </div>
  );
}

export default function TailorDuesClient({ initialData, totals, canPay }: Props) {
  const router = useRouter();
  const idempotency = useIdempotencyKey();

  const [payTarget, setPayTarget] = useState<{ row: TailorDuesRow; kind: PayKind } | null>(null);
  const [amount, setAmount] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<"CASH" | "BANK">("CASH");
  const [notes, setNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const [statement, setStatement] = useState<TailorStatement | null>(null);
  const [statementLoading, setStatementLoading] = useState<string | null>(null);

  function openPay(row: TailorDuesRow, kind: PayKind) {
    setPayTarget({ row, kind });
    setAmount(kind === "SETTLEMENT" ? row.remainingSdg.toFixed(2) : "");
    setPaymentMethod("CASH");
    setNotes("");
  }

  async function openStatement(tailorId: string) {
    setStatementLoading(tailorId);
    try {
      const { data } = await getTailorStatement(tailorId);
      setStatement(data);
    } catch (error: unknown) {
      toast.error(error instanceof Error ? error.message : "تعذر جلب كشف الخياط.");
    } finally {
      setStatementLoading(null);
    }
  }

  async function submitPay(event: React.FormEvent) {
    event.preventDefault();
    if (!payTarget) return;

    const { row, kind } = payTarget;
    const value = Number(amount);
    if (!Number.isFinite(value) || value <= 0 || Number(value.toFixed(2)) !== value) {
      toast.error("أدخل مبلغًا صحيحًا أكبر من صفر.");
      return;
    }
    if (value > row.remainingSdg) {
      toast.error(`المبلغ يتجاوز المستحق المتبقي (${formatSDG(row.remainingSdg)}).`);
      return;
    }

    const payload = {
      tailorId: row.tailorId,
      kind,
      amount: kind === "SETTLEMENT" ? row.remainingSdg : value,
      paymentMethod,
      notes: notes.trim() || null,
    };

    setSubmitting(true);
    try {
      const response = await payTailorDues(payload, {
        idempotencyKey: idempotency.keyFor(payload),
      });
      idempotency.reset();
      toast.success(
        response.message ??
          (kind === "ADVANCE" ? "تم تسجيل السلفة." : "تم سداد المستحقات."),
      );
      setPayTarget(null);
      router.refresh();
    } catch (error: unknown) {
      toast.error(error instanceof Error ? error.message : "تعذر تسجيل الدفعة.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div dir="rtl" className="space-y-6 p-4 pb-12">
      <div className="flex flex-col items-start justify-between gap-4 border-b border-gray-100 pb-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-2xl font-black text-gray-950">مستحقات الخياطين</h1>
          <p className="mt-1 text-sm text-gray-500">
            أجرة الطلبات التي ثُبتت تكلفتها ناقص ما دُفع للخياط. السداد والسلفة
            يُخصمان من المستحق (ليسا مصروفًا) ويُوزعان على الطلبات من الأقدم للأحدث.
          </p>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="rounded-xl border border-gray-200 bg-white p-5">
          <p className="text-sm font-bold text-gray-500">إجمالي المستحق المتبقي</p>
          <p dir="ltr" className="mt-2 text-right text-2xl font-black text-gray-950">
            {formatSDG(totals.remainingSdg)}
          </p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-5">
          <p className="text-sm font-bold text-gray-500">إجمالي السلف المصروفة</p>
          <p dir="ltr" className="mt-2 text-right text-2xl font-black text-amber-700">
            {formatSDG(totals.advancesSdg)}
          </p>
        </div>
      </div>

      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[900px] text-sm">
            <thead className="bg-gray-50 text-xs text-gray-500">
              <tr>
                <th className="px-4 py-3 text-right">الخياط</th>
                <th className="px-4 py-3 text-right">الطلبات المثبتة</th>
                <th className="px-4 py-3 text-right">الأجرة المستحقة</th>
                <th className="px-4 py-3 text-right">المدفوع</th>
                <th className="px-4 py-3 text-right">السلف</th>
                <th className="px-4 py-3 text-right">المتبقي</th>
                <th className="px-4 py-3 text-right">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {initialData.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-4 py-10 text-center text-sm text-gray-400">
                    لا يوجد خياطون في هذا الفرع.
                  </td>
                </tr>
              )}
              {initialData.map((row) => (
                <tr key={row.tailorId}>
                  <td className="px-4 py-3">
                    <p className="font-bold text-gray-900">{row.tailorName}</p>
                    {row.tailorPhone && (
                      <p dir="ltr" className="text-right text-xs text-gray-400">{row.tailorPhone}</p>
                    )}
                  </td>
                  <td className="px-4 py-3 text-gray-700">
                    {row.ordersCount}
                    {row.openOrdersCount > 0 && (
                      <span className="mr-1 text-xs text-gray-400">({row.openOrdersCount} غير مسددة)</span>
                    )}
                  </td>
                  <td dir="ltr" className="px-4 py-3 text-right">{formatSDG(row.costSdg)}</td>
                  <td dir="ltr" className="px-4 py-3 text-right text-emerald-700">{formatSDG(row.paidSdg)}</td>
                  <td dir="ltr" className="px-4 py-3 text-right text-amber-700">{formatSDG(row.advancesSdg)}</td>
                  <td dir="ltr" className="px-4 py-3 text-right font-black text-gray-950">{formatSDG(row.remainingSdg)}</td>
                  <td className="px-4 py-3">
                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={() => openStatement(row.tailorId)}
                        disabled={statementLoading === row.tailorId}
                        className="inline-flex items-center gap-1.5 rounded-lg border border-gray-200 px-3 py-1.5 text-xs font-bold text-gray-700 hover:bg-gray-50 disabled:opacity-50"
                      >
                        <LuFileText className="h-3.5 w-3.5" />
                        {statementLoading === row.tailorId ? "جارٍ التحميل..." : "كشف"}
                      </button>
                      {canPay && row.remainingSdg > 0 && (
                        <>
                          <button
                            type="button"
                            onClick={() => openPay(row, "SETTLEMENT")}
                            className="inline-flex items-center gap-1.5 rounded-lg bg-gray-900 px-3 py-1.5 text-xs font-bold text-white hover:bg-gray-800"
                          >
                            <LuWalletCards className="h-3.5 w-3.5" />
                            سداد كامل
                          </button>
                          <button
                            type="button"
                            onClick={() => openPay(row, "ADVANCE")}
                            className="inline-flex items-center gap-1.5 rounded-lg border border-amber-300 bg-amber-50 px-3 py-1.5 text-xs font-bold text-amber-800 hover:bg-amber-100"
                          >
                            <LuHandCoins className="h-3.5 w-3.5" />
                            سلفة
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {payTarget && canPay && (
        <ModalShell>
          <form
            onSubmit={submitPay}
            dir="rtl"
            className="w-full max-w-sm space-y-4 rounded-2xl bg-white p-5 shadow-2xl"
            noValidate
          >
            <h3 className="text-sm font-black">
              {payTarget.kind === "SETTLEMENT"
                ? `سداد مستحقات ${payTarget.row.tailorName}`
                : `سلفة للخياط ${payTarget.row.tailorName}`}
            </h3>
            <div className="rounded-xl bg-gray-50 p-3 text-xs text-gray-600">
              <p>
                المستحق المتبقي: <strong>{formatSDG(payTarget.row.remainingSdg)}</strong>
              </p>
              <p className="mt-2 font-semibold text-blue-700">
                {payTarget.kind === "SETTLEMENT"
                  ? "يُسدد المستحق كاملًا بالجنيه (مدين مستحقات الخياطين / دائن الخزينة أو البنك)."
                  : "السلفة لا تتجاوز المستحق المتبقي، وتُخصم منه وتظهر منفصلة في كشف الخياط."}
              </p>
            </div>
            <label className="block">
              <span className="text-xs font-bold text-gray-600">المبلغ (ج.س)</span>
              <input
                value={amount}
                onChange={(event) => setAmount(event.target.value)}
                readOnly={payTarget.kind === "SETTLEMENT"}
                disabled={submitting}
                type="number"
                min="0.01"
                max={payTarget.row.remainingSdg}
                step="0.01"
                inputMode="decimal"
                className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2.5 text-sm read-only:bg-gray-50"
              />
            </label>
            <label className="block">
              <span className="text-xs font-bold text-gray-600">طريقة الدفع</span>
              <select
                value={paymentMethod}
                onChange={(event) => setPaymentMethod(event.target.value as "CASH" | "BANK")}
                disabled={submitting}
                className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2.5 text-sm"
              >
                <option value="CASH">نقداً / الخزينة</option>
                <option value="BANK">حوالة / البنك</option>
              </select>
            </label>
            <label className="block">
              <span className="text-xs font-bold text-gray-600">ملاحظات</span>
              <textarea
                value={notes}
                onChange={(event) => setNotes(event.target.value)}
                maxLength={500}
                rows={2}
                disabled={submitting}
                className="mt-1 w-full resize-none rounded-xl border border-gray-300 px-3 py-2.5 text-sm"
              />
            </label>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setPayTarget(null)}
                disabled={submitting}
                className="flex-1 rounded-xl border border-gray-200 py-2.5 text-xs font-bold"
              >
                إلغاء
              </button>
              <button
                type="submit"
                disabled={submitting}
                className="flex-1 rounded-xl bg-gray-900 py-2.5 text-xs font-bold text-white disabled:opacity-50"
              >
                {submitting
                  ? "جارٍ الحفظ..."
                  : payTarget.kind === "SETTLEMENT"
                    ? "تأكيد السداد"
                    : "تسجيل السلفة"}
              </button>
            </div>
          </form>
        </ModalShell>
      )}

      {statement && (
        <ModalShell>
          <div dir="rtl" className="max-h-[90vh] w-full max-w-4xl overflow-y-auto rounded-2xl bg-white p-5 shadow-2xl">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-base font-black">كشف الخياط {statement.summary.tailorName}</h3>
              <button
                type="button"
                onClick={() => setStatement(null)}
                className="rounded-lg p-1.5 text-gray-500 hover:bg-gray-100"
                aria-label="إغلاق"
              >
                <LuX className="h-5 w-5" />
              </button>
            </div>

            <div className="grid gap-3 sm:grid-cols-4">
              {[
                { label: "الأجرة المستحقة", value: statement.summary.costSdg, cls: "text-gray-950" },
                { label: "المدفوع", value: statement.summary.paidSdg, cls: "text-emerald-700" },
                { label: "السلف", value: statement.summary.advancesSdg, cls: "text-amber-700" },
                { label: "المتبقي", value: statement.summary.remainingSdg, cls: "text-red-600" },
              ].map((card) => (
                <div key={card.label} className="rounded-xl bg-gray-50 p-3">
                  <p className="text-[11px] font-bold text-gray-400">{card.label}</p>
                  <p dir="ltr" className={`mt-1 text-right text-sm font-black ${card.cls}`}>
                    {formatSDG(card.value)}
                  </p>
                </div>
              ))}
            </div>

            <h4 className="mb-2 mt-5 text-sm font-black">الطلبات المثبتة تكلفتها</h4>
            <div className="overflow-x-auto rounded-xl border border-gray-100">
              <table className="w-full min-w-[640px] text-xs">
                <thead className="bg-gray-50 text-gray-500">
                  <tr>
                    <th className="px-3 py-2 text-right">الطلب</th>
                    <th className="px-3 py-2 text-right">تاريخ التثبيت</th>
                    <th className="px-3 py-2 text-right">الأجرة</th>
                    <th className="px-3 py-2 text-right">المدفوع</th>
                    <th className="px-3 py-2 text-right">السلف</th>
                    <th className="px-3 py-2 text-right">المتبقي</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {statement.orders.length === 0 && (
                    <tr>
                      <td colSpan={6} className="px-3 py-6 text-center text-gray-400">لا توجد طلبات مثبتة.</td>
                    </tr>
                  )}
                  {statement.orders.map((order) => (
                    <tr key={order.salesOrderId}>
                      <td className="px-3 py-2">
                        <a href={`/dashboard/tailoring/${order.salesOrderId}`} className="font-bold text-blue-700 hover:underline">
                          {order.orderNumber}
                        </a>
                        {order.itemName && <span className="block text-gray-400">{order.itemName}</span>}
                      </td>
                      <td className="px-3 py-2 text-gray-500">{dateTimeLabel(order.costRecognizedAt)}</td>
                      <td dir="ltr" className="px-3 py-2 text-right">{formatSDG(order.costSdg)}</td>
                      <td dir="ltr" className="px-3 py-2 text-right text-emerald-700">{formatSDG(order.paidSdg)}</td>
                      <td dir="ltr" className="px-3 py-2 text-right text-amber-700">{formatSDG(order.advancesSdg)}</td>
                      <td dir="ltr" className="px-3 py-2 text-right font-black">{formatSDG(order.remainingSdg)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {(["SETTLEMENT", "DUES_ADVANCE"] as const).map((type) => {
              const rows = statement.payments.filter((payment) =>
                type === "SETTLEMENT" ? payment.paymentType !== "DUES_ADVANCE" : payment.paymentType === type,
              );
              return (
                <div key={type}>
                  <h4 className="mb-2 mt-5 text-sm font-black">
                    {type === "SETTLEMENT" ? "المدفوعات" : "السلف"}
                  </h4>
                  <div className="overflow-x-auto rounded-xl border border-gray-100">
                    <table className="w-full min-w-[640px] text-xs">
                      <thead className="bg-gray-50 text-gray-500">
                        <tr>
                          <th className="px-3 py-2 text-right">التاريخ</th>
                          <th className="px-3 py-2 text-right">النوع</th>
                          <th className="px-3 py-2 text-right">الطلب</th>
                          <th className="px-3 py-2 text-right">المبلغ</th>
                          <th className="px-3 py-2 text-right">الطريقة</th>
                          <th className="px-3 py-2 text-right">ملاحظات / المرجع</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100">
                        {rows.length === 0 && (
                          <tr>
                            <td colSpan={6} className="px-3 py-6 text-center text-gray-400">لا يوجد.</td>
                          </tr>
                        )}
                        {rows.map((payment) => (
                          <tr key={payment.id}>
                            <td className="px-3 py-2 text-gray-500">{dateTimeLabel(payment.createdAt)}</td>
                            <td className="px-3 py-2 font-semibold">{PAYMENT_TYPE_LABELS[payment.paymentType]}</td>
                            <td className="px-3 py-2">{payment.orderNumber ?? "-"}</td>
                            <td dir="ltr" className="px-3 py-2 text-right font-black">
                              {formatSDG(payment.amountSdg)}
                              <span className="block text-[10px] font-semibold text-gray-400">≈ {formatUSD(payment.amountUsd)}</span>
                            </td>
                            <td className="px-3 py-2">{payment.paymentMethod === "BANK" ? "البنك" : "الخزينة"}</td>
                            <td className="px-3 py-2 text-gray-500">{payment.notes ?? "-"}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              );
            })}
          </div>
        </ModalShell>
      )}
    </div>
  );
}
