"use client";

/**
 * الأرصدة الافتتاحية — تبويبان، وكل تبويب يقبل الإدخال أكثر من مرة لاستكمال ما نُسي:
 *   • الفلوس: مبلغ + حساب (خزينة/بنك) + عملة ← قيد رأس مال
 *   • المخزون: منتج ومتغير + كمية + تكلفة الوحدة بالدولار ← رصيد + متوسط مرجح + قيد رأس مال
 */

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";
import { LuBoxes, LuWallet } from "react-icons/lu";

import BackLink from "@/components/shared/BackLink";
import { serverFetch } from "@/lib/api-client";
import { formatQuantity, formatSDG, formatUSD } from "@/lib/currency";
import { useIdempotencyKey } from "@/lib/use-idempotency-key";

export interface OpeningEntryRow {
  id: string;
  entryNumber: string;
  description: string;
  kind: "CASH" | "INVENTORY";
  currency: "SDG" | "USD";
  amount: number;
  amountUsd: number;
  createdAt: string;
}

export interface OpeningVariantOption {
  id: string;
  productName: string;
  variantLabel: string;
  sku: string | null;
  unit: string;
  stock: number;
  averageCost: number;
}

interface Props {
  entries: OpeningEntryRow[];
  variants: OpeningVariantOption[];
}

type Tab = "CASH" | "INVENTORY";

const inputClass =
  "w-full rounded-xl border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm outline-none focus:border-(--primary-red) focus:bg-white";

function dateTimeLabel(value: string) {
  return new Intl.DateTimeFormat("ar-SA-u-nu-latn", {
    dateStyle: "medium",
    timeStyle: "short",
    timeZone: "Africa/Khartoum",
  }).format(new Date(value));
}

export default function OpeningBalancesTabs({ entries, variants }: Props) {
  const router = useRouter();
  const idempotency = useIdempotencyKey();
  const [tab, setTab] = useState<Tab>("CASH");
  const [saving, setSaving] = useState(false);

  // الفلوس
  const [account, setAccount] = useState<"CASH" | "BANK">("CASH");
  const [currency, setCurrency] = useState<"SDG" | "USD">("SDG");
  const [amount, setAmount] = useState("");
  const [cashNotes, setCashNotes] = useState("");

  // المخزون
  const [search, setSearch] = useState("");
  const [variantId, setVariantId] = useState("");
  const [quantity, setQuantity] = useState("");
  const [unitCost, setUnitCost] = useState("");
  const [stockNotes, setStockNotes] = useState("");

  const filteredVariants = useMemo(() => {
    const term = search.trim().toLowerCase();
    const list = term
      ? variants.filter((variant) =>
          [variant.productName, variant.variantLabel, variant.sku ?? ""].some((text) =>
            text.toLowerCase().includes(term),
          ),
        )
      : variants;
    return list.slice(0, 200);
  }, [search, variants]);

  const selectedVariant = variants.find((variant) => variant.id === variantId) ?? null;
  const visibleEntries = entries.filter((entry) => entry.kind === tab);

  async function submit(payload: Record<string, unknown>, reset: () => void) {
    setSaving(true);
    try {
      const response = await serverFetch<{ message?: string }>("/api/accounting/opening-balances/entry", {
        method: "POST",
        body: JSON.stringify(payload),
        headers: { "Idempotency-Key": idempotency.keyFor(payload) },
      });
      idempotency.reset();
      toast.success(response.message ?? "تم التسجيل.");
      reset();
      router.refresh();
    } catch (error: unknown) {
      toast.error(error instanceof Error ? error.message : "تعذر تسجيل الرصيد الافتتاحي.");
    } finally {
      setSaving(false);
    }
  }

  function submitCash(event: React.FormEvent) {
    event.preventDefault();
    const value = Number(amount);
    if (!Number.isFinite(value) || value <= 0) {
      toast.error("أدخل مبلغًا أكبر من صفر.");
      return;
    }
    void submit(
      { kind: "CASH", account, currency, amount: value, notes: cashNotes.trim() || null },
      () => {
        setAmount("");
        setCashNotes("");
      },
    );
  }

  function submitInventory(event: React.FormEvent) {
    event.preventDefault();
    const qty = Number(quantity);
    const cost = Number(unitCost);
    if (!variantId) {
      toast.error("اختر المنتج والمتغير.");
      return;
    }
    if (!Number.isFinite(qty) || qty <= 0 || !Number.isFinite(cost) || cost <= 0) {
      toast.error("أدخل كمية وتكلفة وحدة أكبر من صفر.");
      return;
    }
    void submit(
      { kind: "INVENTORY", variantId, quantity: qty, unitCost: cost, notes: stockNotes.trim() || null },
      () => {
        setQuantity("");
        setUnitCost("");
        setStockNotes("");
      },
    );
  }

  return (
    <main dir="rtl" className="space-y-6 p-4 pb-12">
      <div className="border-b border-gray-100 pb-4">
        <div className="mb-3">
          <BackLink href="/dashboard/accounting" label="العودة إلى المحاسبة" />
        </div>
        <h1 className="text-2xl font-black text-gray-950">الأرصدة الافتتاحية</h1>
        <p className="mt-1 text-sm text-gray-500">
          كل إدخال قيد رأس مال مستقل، ويمكن الإدخال أكثر من مرة لاستكمال ما نُسي.
        </p>
      </div>

      <div className="flex gap-2 border-b border-gray-200">
        {(
          [
            ["CASH", "الفلوس", LuWallet],
            ["INVENTORY", "المخزون", LuBoxes],
          ] as const
        ).map(([id, label, Icon]) => (
          <button
            key={id}
            type="button"
            onClick={() => setTab(id)}
            className={`-mb-px flex items-center gap-2 border-b-2 px-4 py-3 text-sm font-bold transition ${
              tab === id
                ? "border-(--primary-red) text-(--primary-red)"
                : "border-transparent text-gray-500 hover:text-gray-800"
            }`}
          >
            <Icon className="h-4 w-4" />
            {label}
          </button>
        ))}
      </div>

      {tab === "CASH" ? (
        <form onSubmit={submitCash} className="grid gap-4 rounded-2xl border border-gray-200 bg-white p-5 sm:grid-cols-2 lg:grid-cols-4" noValidate>
          <label className="block">
            <span className="text-xs font-bold text-gray-600">الحساب</span>
            <select value={account} onChange={(event) => setAccount(event.target.value as "CASH" | "BANK")} className={inputClass} disabled={saving}>
              <option value="CASH">الخزينة</option>
              <option value="BANK">البنك</option>
            </select>
          </label>
          <label className="block">
            <span className="text-xs font-bold text-gray-600">العملة</span>
            <select value={currency} onChange={(event) => setCurrency(event.target.value as "SDG" | "USD")} className={inputClass} disabled={saving}>
              <option value="SDG">جنيه سوداني</option>
              <option value="USD">دولار</option>
            </select>
          </label>
          <label className="block">
            <span className="text-xs font-bold text-gray-600">المبلغ</span>
            <input type="number" min="0.01" step="0.01" inputMode="decimal" value={amount} onChange={(event) => setAmount(event.target.value)} className={inputClass} disabled={saving} />
          </label>
          <label className="block">
            <span className="text-xs font-bold text-gray-600">ملاحظات</span>
            <input value={cashNotes} onChange={(event) => setCashNotes(event.target.value)} maxLength={300} className={inputClass} disabled={saving} />
          </label>
          <div className="sm:col-span-2 lg:col-span-4">
            <button type="submit" disabled={saving} className="rounded-xl bg-gray-900 px-6 py-2.5 text-xs font-bold text-white disabled:opacity-50">
              {saving ? "جارٍ الحفظ..." : "تسجيل الرصيد"}
            </button>
          </div>
        </form>
      ) : (
        <form onSubmit={submitInventory} className="grid gap-4 rounded-2xl border border-gray-200 bg-white p-5 lg:grid-cols-2" noValidate>
          <div className="space-y-2 lg:col-span-2">
            <span className="text-xs font-bold text-gray-600">المنتج والمتغير</span>
            <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="ابحث بالاسم أو SKU..." className={inputClass} disabled={saving} />
            <select value={variantId} onChange={(event) => setVariantId(event.target.value)} className={inputClass} size={6} disabled={saving}>
              {filteredVariants.map((variant) => (
                <option key={variant.id} value={variant.id}>
                  {variant.productName}
                  {variant.variantLabel ? ` — ${variant.variantLabel}` : ""}
                  {variant.sku ? ` (${variant.sku})` : ""} — الرصيد {formatQuantity(variant.stock)} {variant.unit}
                </option>
              ))}
            </select>
            {selectedVariant && (
              <p className="text-xs text-gray-500">
                الرصيد الحالي: {formatQuantity(selectedVariant.stock)} {selectedVariant.unit} — متوسط التكلفة:{" "}
                {formatUSD(selectedVariant.averageCost)}
              </p>
            )}
          </div>
          <label className="block">
            <span className="text-xs font-bold text-gray-600">الكمية</span>
            <input type="number" min="0.01" step="0.01" inputMode="decimal" value={quantity} onChange={(event) => setQuantity(event.target.value)} className={inputClass} disabled={saving} />
          </label>
          <label className="block">
            <span className="text-xs font-bold text-gray-600">تكلفة الوحدة ($)</span>
            <input type="number" min="0.01" step="0.01" inputMode="decimal" value={unitCost} onChange={(event) => setUnitCost(event.target.value)} className={inputClass} disabled={saving} />
          </label>
          <label className="block lg:col-span-2">
            <span className="text-xs font-bold text-gray-600">ملاحظات</span>
            <input value={stockNotes} onChange={(event) => setStockNotes(event.target.value)} maxLength={300} className={inputClass} disabled={saving} />
          </label>
          {Number(quantity) > 0 && Number(unitCost) > 0 && (
            <p className="text-xs font-semibold text-emerald-700 lg:col-span-2">
              القيمة: {formatUSD(Number(quantity) * Number(unitCost))} (مدين المخزون / دائن رأس المال)
            </p>
          )}
          <div className="lg:col-span-2">
            <button type="submit" disabled={saving} className="rounded-xl bg-gray-900 px-6 py-2.5 text-xs font-bold text-white disabled:opacity-50">
              {saving ? "جارٍ الحفظ..." : "تسجيل المخزون"}
            </button>
          </div>
        </form>
      )}

      <section className="overflow-hidden rounded-2xl border border-gray-200 bg-white">
        <h2 className="border-b border-gray-100 px-5 py-3 text-sm font-black">ما تم تسجيله</h2>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px] text-sm">
            <thead className="bg-gray-50 text-xs text-gray-500">
              <tr>
                <th className="px-4 py-2 text-right">التاريخ</th>
                <th className="px-4 py-2 text-right">البيان</th>
                <th className="px-4 py-2 text-right">المبلغ</th>
                <th className="px-4 py-2 text-right">بالدولار</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {visibleEntries.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-4 py-8 text-center text-gray-400">لا يوجد بعد.</td>
                </tr>
              )}
              {visibleEntries.map((entry) => (
                <tr key={entry.id}>
                  <td className="px-4 py-2 text-xs text-gray-500">{dateTimeLabel(entry.createdAt)}</td>
                  <td className="px-4 py-2">{entry.description}</td>
                  <td dir="ltr" className="px-4 py-2 text-right font-bold">
                    {entry.currency === "SDG" ? formatSDG(entry.amount) : formatUSD(entry.amount)}
                  </td>
                  <td dir="ltr" className="px-4 py-2 text-right text-gray-500">{formatUSD(entry.amountUsd)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </main>
  );
}
