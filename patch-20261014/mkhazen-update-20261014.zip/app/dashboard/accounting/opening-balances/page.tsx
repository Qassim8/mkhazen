import { redirect } from "next/navigation";

import { getSession } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { MAIN_BRANCH_ID } from "@/lib/constants";
import { supabaseAdmin } from "@/lib/supabase";
import { fetchAll } from "@/lib/supabase-fetch-all";

import OpeningBalancesTabs, {
  type OpeningEntryRow,
  type OpeningVariantOption,
} from "../_components/OpeningBalancesTabs";

export const dynamic = "force-dynamic";

function variantLabel(variant: Record<string, unknown>) {
  return [
    variant.colorName ? String(variant.colorName) : null,
    variant.size ? `مقاس ${variant.size}` : null,
  ]
    .filter(Boolean)
    .join(" • ");
}

export default async function OpeningBalancesPage() {
  const user = await getSession();

  if (!user || !can(user.role, "accounting.openingBalances")) {
    redirect("/dashboard/accounting");
  }

  const [entriesResult, variants] = await Promise.all([
    supabaseAdmin
      .from("journal_entries")
      .select("id, entry_number, description, debit_account, currency, amount, amount_usd, created_at")
      .eq("branch_id", MAIN_BRANCH_ID)
      .eq("entry_type", "CAPITAL")
      .or("entry_number.like.JE-OPENCASH-%,entry_number.like.JE-OPENINV-%,entry_number.like.JE-OPENBAL-%,entry_number.like.JE-OPEN-%")
      .order("created_at", { ascending: false })
      .limit(200),
    fetchAll<Record<string, unknown>>((from, to) =>
      supabaseAdmin
        .from("product_variants")
        .select('id, sku, "colorName", size, "stockQuantity", "averageCost", "isActive", product_templates!inner(name, "sellingUnit", "isActive")')
        .eq("isActive", true)
        .order("id")
        .range(from, to),
    ),
  ]);

  if (entriesResult.error) {
    throw new Error(`تعذر جلب الأرصدة الافتتاحية: ${entriesResult.error.message}`);
  }

  const entries: OpeningEntryRow[] = (entriesResult.data ?? []).map((row) => ({
    id: String(row.id),
    entryNumber: String(row.entry_number),
    description: row.description ? String(row.description) : "",
    kind: row.debit_account === "INVENTORY" ? "INVENTORY" : "CASH",
    currency: row.currency === "SDG" ? "SDG" : "USD",
    amount: Number(row.amount ?? 0),
    amountUsd: Number(row.amount_usd ?? 0),
    createdAt: String(row.created_at),
  }));

  const variantOptions: OpeningVariantOption[] = variants
    .map((variant) => {
      const template = (variant.product_templates ?? {}) as Record<string, unknown>;
      return {
        id: String(variant.id),
        productName: String(template.name ?? "منتج"),
        variantLabel: variantLabel(variant),
        sku: variant.sku ? String(variant.sku) : null,
        unit: template.sellingUnit ? String(template.sellingUnit) : "",
        stock: Number(variant.stockQuantity ?? 0),
        averageCost: Number(variant.averageCost ?? 0),
        templateActive: template.isActive !== false,
      };
    })
    .filter((variant) => variant.templateActive)
    .map(({ templateActive: _ignored, ...variant }) => variant)
    .sort((a, b) => a.productName.localeCompare(b.productName, "ar"));

  return <OpeningBalancesTabs entries={entries} variants={variantOptions} />;
}
