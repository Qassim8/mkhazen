"use client";

/**
 * فاتورة طلب التفصيل 80mm — نسختان في صفحة واحدة بينهما خط قص
 * ("نسخة العميل" و"نسخة المحل"). بدون أي تكاليف داخلية.
 * تظهر في الطباعة فقط (window.print) وباقي الصفحة مخفي.
 */

import { formatSDG } from "@/lib/currency";
import { STORE_INFO } from "@/lib/store";

import type { TailoringOrder } from "../schemas/tailoring.schemas";

function dateLabel(value: string | null | undefined) {
  if (!value) return "-";
  return new Intl.DateTimeFormat("ar-SA-u-nu-latn", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date(`${value.slice(0, 10)}T00:00:00`));
}

function Row({ label, value, strong = false }: { label: string; value: string; strong?: boolean }) {
  return (
    <div className={`flex justify-between gap-3 ${strong ? "text-[12px] font-bold" : ""}`}>
      <span>{label}</span>
      <span className="text-left">{value}</span>
    </div>
  );
}

function Copy({ order, label }: { order: TailoringOrder; label: string }) {
  return (
    <section className="px-3 py-2 text-[11px] text-black" dir="rtl">
      <div className="border-b border-dashed border-black pb-2 text-center">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={STORE_INFO.logo} alt={STORE_INFO.name} className="mx-auto mb-1 h-12 w-auto object-contain" />
        <p className="text-base font-bold">{STORE_INFO.name}</p>
        <p className="text-[11px]">فاتورة طلب تفصيل</p>
        <p className="mt-1 inline-block rounded border border-black px-2 text-[10px] font-black">{label}</p>
      </div>

      <div className="space-y-1 border-b border-dashed border-black py-2">
        <Row label="رقم الطلب" value={order.orderNumber} strong />
        <Row label="العميل" value={order.customer?.name ?? "-"} />
        <Row label="واتساب" value={order.customer?.whatsappNumber ?? "-"} />
        <Row label="القطعة" value={order.tailoringItemName} />
        <Row label="تاريخ الاستلام" value={dateLabel(order.intakeDate)} />
        <Row label="تاريخ التسليم" value={dateLabel(order.expectedDeliveryDate)} />
      </div>

      <div className="space-y-1 py-2">
        <Row label="الإجمالي" value={formatSDG(order.totalAmount)} strong />
        <Row label="المدفوع" value={formatSDG(order.paidAmount)} />
        <Row label="المتبقي" value={formatSDG(order.remainingAmount)} strong />
      </div>

      <p className="border-t border-dashed border-black pt-2 text-center text-[10px]" dir="ltr">
        للتواصل: {STORE_INFO.phone}
      </p>
    </section>
  );
}

export default function TailoringReceipt({ order }: { order: TailoringOrder }) {
  return (
    <>
      <div id="tailoring-receipt-print" className="hidden print:block" aria-hidden="true">
        <div className="w-[80mm] bg-white">
          <Copy order={order} label="نسخة العميل" />
          <div className="my-2 flex items-center gap-1 px-2 text-[9px] text-black">
            <span>✂</span>
            <span className="flex-1 border-t border-dashed border-black" />
            <span>قص هنا</span>
            <span className="flex-1 border-t border-dashed border-black" />
          </div>
          <Copy order={order} label="نسخة المحل" />
        </div>
      </div>

      <style jsx global>{`
        @media print {
          @page {
            size: 80mm auto;
            margin: 0;
          }
          html,
          body {
            width: 80mm;
            margin: 0;
            padding: 0;
            background: white !important;
          }
          body * {
            visibility: hidden;
          }
          #tailoring-receipt-print,
          #tailoring-receipt-print * {
            visibility: visible;
          }
          #tailoring-receipt-print {
            position: absolute;
            inset: 0 auto auto 0;
            width: 80mm;
          }
        }
      `}</style>
    </>
  );
}
